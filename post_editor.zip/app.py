import asyncio
import logging

from aiogram import Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.contrib.fsm_storage.redis import RedisStorage2

from loader import config, bot
from tg_bot.filters import register_all_filters
from tg_bot.handlers.admin import register_admin_menu
from tg_bot.handlers.errors import register_errors_handler
from tg_bot.handlers.users import register_user_menu
from tg_bot.middlewares import register_all_middlewares
from tg_bot.services.on_startup_notify import on_startup_notify
from tg_bot.services.set_default_commands import set_default_commands


async def start_bot():
    if config.redis.use_redis:
        storage = RedisStorage2()
    else:
        storage = MemoryStorage()

    dp = Dispatcher(bot, storage=storage)

    bot["config"] = config

    await set_default_commands(dp)
    await on_startup_notify(dp)

    register_all_middlewares(dp)
    register_all_filters(dp)
    register_errors_handler(dp)
    register_user_menu(dp)
    register_admin_menu(dp)

    try:
        await dp.start_polling()
    finally:
        await dp.storage.close()
        await dp.storage.wait_closed()
        await bot.session.close()


if __name__ == '__main__':
    try:
        asyncio.run(start_bot())
    except (KeyboardInterrupt, SystemExit):
        logging.error("Bot stopped!")
