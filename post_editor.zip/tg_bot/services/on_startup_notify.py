import logging

from aiogram import Dispatcher

from tg_bot.config import Config


async def on_startup_notify(dp: Dispatcher):
    config: Config = dp.bot.get("config")

    for admin in config.bot.admins:
        try:
            await dp.bot.send_message(admin, "Бот запущен")
            logging.debug(">> Bot started")
        except Exception as err:
            logging.exception(err)
