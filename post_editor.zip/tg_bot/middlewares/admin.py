import logging

from aiogram.dispatcher.handler import CancelHandler
from aiogram.dispatcher.middlewares import BaseMiddleware
from aiogram.types import Message

from tg_bot.config import Config


# db: Database, action: str
class CheckIsAdminMiddleware(BaseMiddleware):

    async def on_process_message(self, message: Message, data: dict):
        user_id = message.from_user.id

        config: Config = message.bot.get("config")

        if user_id not in config.bot.admins:
            print(config.bot.admins)
            logging.info(f"Доступ для юзера {user_id} закрыт! Не отвечаю ему :)")
            await message.answer("⚙️ Доступ открыт только для администраторов!")
            raise CancelHandler()
