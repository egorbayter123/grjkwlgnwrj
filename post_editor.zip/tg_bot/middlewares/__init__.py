from aiogram import Dispatcher

from .admin import CheckIsAdminMiddleware


def register_all_middlewares(dp: Dispatcher):
    dp.middleware.setup(CheckIsAdminMiddleware())