from aiogram.dispatcher.filters import state
from aiogram.dispatcher.filters.state import State, StatesGroup


class EditAdminState(StatesGroup):
    WAIT_DELETE_ID = State()
    WAIT_ADD_ID = State()


class EditPostsState(StatesGroup):
    WAIT_LINKS = State()
    WAIT_TEXT = State()
    WAIT_BUTTONS = State()

