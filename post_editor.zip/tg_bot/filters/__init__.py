from aiogram import Dispatcher

from tg_bot.filters.is_admin import AdminFilter


def register_all_filters(dp: Dispatcher):
    dp.filters_factory.bind(AdminFilter)
