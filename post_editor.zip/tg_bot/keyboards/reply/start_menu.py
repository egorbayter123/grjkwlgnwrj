from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

edit_posts_btn = KeyboardButton("Отредактировать посты")
start_menu_keyboard = ReplyKeyboardMarkup(row_width=1, resize_keyboard=True, one_time_keyboard=True).add(edit_posts_btn)

return_start_menu_btn = KeyboardButton("Назад")
return_start_menu_keyboard = ReplyKeyboardMarkup(row_width=1, resize_keyboard=True).add(return_start_menu_btn)