from aiogram import Dispatcher
from aiogram.dispatcher.filters import Command, Text

from tg_bot.states import EditAdminState
from .edit_admins import add_admin_callback, add_admin, delete_admin_callback, delete_admin
from .get_logs import get_logs
from .main import start_admin_menu, return_admin_menu


def register_edit_admins(dp: Dispatcher):
    dp.register_callback_query_handler(add_admin_callback, Text("add_admin"), state="*")
    dp.register_message_handler(add_admin, state=EditAdminState.WAIT_ADD_ID)

    dp.register_callback_query_handler(delete_admin_callback, Text("delete_admin"), state="*")
    dp.register_message_handler(delete_admin, state=EditAdminState.WAIT_DELETE_ID)



def register_get_logs(dp: Dispatcher):
    dp.register_callback_query_handler(get_logs, Text("get_logs_admin"), state="*")


def register_start_message_admin_menu(dp: Dispatcher):
    dp.register_message_handler(start_admin_menu, Command("admin", prefixes="/"), state="*")
    dp.register_callback_query_handler(return_admin_menu, Text("return_admin_menu"), state="*")


def register_admin_menu(dp: Dispatcher):
    register_start_message_admin_menu(dp)
    register_edit_admins(dp)
    register_get_logs(dp)