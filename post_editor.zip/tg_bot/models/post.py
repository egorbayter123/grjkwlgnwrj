from dataclasses import dataclass
from typing import Union


@dataclass
class Post:
    entity: Union[str, int]
    message_id: int

'''    
posts_dict = [
    {
        posts: list[Post],
        post_text: sdsdsd,
        post_keyboard: sdsdsd
    }
]
'''
